import React from 'react'
export default function Header() {
    return (
        <div>
            <h1>Employee Directory</h1>
        </div>
    )
}